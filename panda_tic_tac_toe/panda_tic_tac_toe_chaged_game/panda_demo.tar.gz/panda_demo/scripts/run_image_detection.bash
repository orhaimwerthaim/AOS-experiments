export PYTHONPATH=/home/or/catkin_ws/devel/lib/python3/dist-packages
python3 /home/or/catkin_ws/src/panda_demo/scripts/image_detection_borad_state.py
export PYTHONPATH=/home/or/catkin_ws/devel/lib/python3/dist-packages:/opt/ros/kinetic/lib/python2.7/dist-packages
